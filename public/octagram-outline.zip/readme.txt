Thanks for visiting MaterialDesignIcons.com
Check back often for new icons and follow @MaterialIcons for updates.

Icon: octagram-outline
By: Austin Andrews @Templarian